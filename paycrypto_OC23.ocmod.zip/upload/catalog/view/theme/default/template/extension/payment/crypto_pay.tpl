<h2><?php echo $text_instruction; ?></h2>
<p><b><?php echo $text_description; ?></b></p>
<div class="well well-sm">
  <p><?php echo $wallet; ?></p>
  <p><?php echo $text_payment; ?></p>
  <div class="paycrypto-trc20">
    <p style="margin-top: 10px; margin-bottom: 10px;"><b>* Порядок действий:</b><br>1) оплатите заказ,<br>2) нажмите кнопку "ПОДТВЕРДИТЬ ЗАКАЗ"</p>
    <p style="margin-bottom: 10px;"><i>**для того, чтобы не вводить адрес кошелька вручную - можно просто отсканировать код с картинки ниже:</i></p>
    <img src="<?php echo $paycrypto_image_folder; ?>nie-qun-trc20.jpg" alt="Отсканируйте QR для оплаты">
  </div>
</div>
<div class="buttons">
  <div class="pull-right">
    <input type="button" value="<?php echo $button_confirm; ?>" id="button-confirm" class="btn btn-primary" data-loading-text="<?php echo $text_loading; ?>" />
  </div>
</div>
<script type="text/javascript"><!--
$('#button-confirm').on('click', function() {
	$.ajax({
		type: 'get',
		url: 'index.php?route=extension/payment/crypto_pay/confirm',
		cache: false,
		beforeSend: function() {
			$('#button-confirm').button('loading');
		},
		complete: function() {
			$('#button-confirm').button('reset');
		},
		success: function() {
			location = '<?php echo $continue; ?>';
		}
	});
});
//--></script>
