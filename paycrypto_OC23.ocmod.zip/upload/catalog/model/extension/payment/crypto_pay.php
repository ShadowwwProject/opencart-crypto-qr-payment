<?php
class ModelExtensionPaymentCryptoPay extends Model {
    public function getMethod($address, $total) {
        // load language for title
        $this->load->language('extension/payment/crypto_pay');

        // only show if enabled and total meets requirement
        if ($this->config->get('crypto_pay_status') && $total > 0) {
            return [
                'code'       => 'crypto_pay',
                'title'      => $this->language->get('text_title'),
                'terms'      => '',
                'sort_order' => $this->config->get('crypto_pay_sort_order')
            ];
        }

        return [];
    }
}
