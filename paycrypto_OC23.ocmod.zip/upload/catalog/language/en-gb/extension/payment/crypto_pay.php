<?php
// Text
$_['text_title']				= 'Pay Crypto';
$_['text_instruction']			= 'Crypto Payment Instructions';
$_['text_description']			= 'Please transfer the total amount to any of the following crypto wallets (pick up the most convenient way).';
$_['text_payment']				= 'Your order will not be shipped until we receive the payment.';
$_['payment_procedure']			= '<p style="margin-top: 10px; margin-bottom: 10px;"><b>* Steps:</b><br>1) Pay for your order,<br>2) Click the "CONFIRM ORDER" button.</p><p style="margin-bottom: 10px;"><i>**To avoid entering your wallet address manually, you can simply scan the code from the image below:</i></p>';

// Button
$_['text_loading']      = 'Loading...';
$_['button_confirm']    = 'Confirm Order';