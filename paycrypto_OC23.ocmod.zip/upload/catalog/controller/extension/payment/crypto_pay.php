<?php
class ControllerExtensionPaymentCryptoPay extends Controller {
	public function index() {
		// Define the basic URL of the web store
		$store_url = $this->config->get('config_ssl') && $this->request->server['HTTPS']
		    ? $this->config->get('config_ssl')
		    : $this->config->get('config_url');
		// Assemle the URL
		$data['paycrypto_image_folder'] = $store_url . 'image/payment/paycrypto/';

		$this->load->language('extension/payment/crypto_pay');

		$data['text_instruction'] = $this->language->get('text_instruction');
		$data['text_description'] = $this->language->get('text_description');
		$data['text_payment'] = $this->language->get('text_payment');
		$data['text_loading'] = $this->language->get('text_loading');
		$data['payment_procedure'] = $this->language->get('payment_procedure');

		$data['button_confirm'] = $this->language->get('button_confirm');

		// we get the text (or HTML) saved in the admin panel in the current language
		$address = $this->config->get('crypto_pay_bank' . $this->config->get('config_language_id'));

		// flag from admin panel: output as HTML or as plain text
		$render_html = $this->config->get('crypto_pay_render_html' . $this->config->get('config_language_id'));

		// if the admin enabled "Render as HTML", then we decode the entities and output the raw HTML
		if ($render_html) {
		    $data['wallet'] = html_entity_decode($address, ENT_QUOTES, 'UTF-8');
		} else {
		    // otherwise we escape the tags and turn line breaks into <br>
		    $data['wallet'] = nl2br(htmlspecialchars($address, ENT_QUOTES, 'UTF-8'));
		}


		$data['continue'] = $this->url->link('checkout/success');

		return $this->load->view('extension/payment/crypto_pay', $data);
	}

	public function confirm() {
		if ($this->session->data['payment_method']['code'] == 'crypto_pay') {
			$this->load->language('extension/payment/crypto_pay');

			$this->load->model('checkout/order');

			$comment  = $this->language->get('text_instruction') . "\n\n";
			$comment .= $this->config->get('crypto_pay_bank' . $this->config->get('config_language_id')) . "\n\n";
			$comment .= $this->language->get('text_payment');

			$this->model_checkout_order->addOrderHistory(
				$this->session->data['order_id'], 
				$this->config->get('crypto_pay_order_status_id'), 
				$comment, 
				true
			);
		}
	}
}