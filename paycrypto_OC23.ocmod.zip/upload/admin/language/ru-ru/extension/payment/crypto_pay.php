<?php
// Heading
$_['heading_title']		 = 'Оплата криптой от Shadowww';

// Text
$_['text_extension']	 = 'Расширения';
$_['text_success']		 = 'Успех: Вы изменили данные криптоплатежа!';
$_['text_edit']          = 'Редактировать информацию о блокчейне';

// Entry
$_['entry_bank']		 = 'Адрес криптокошелька';
$_['entry_total']		 = 'Итого';
$_['entry_order_status'] = 'Статус Заказа';
$_['entry_geo_zone']	 = 'ГЕО Зона';
$_['entry_status']		 = 'Статус';
$_['entry_sort_order']	 = 'Сортировка заказа';
$_['entry_render_html']	 = 'Вывести как HTML';

// Help
$_['help_total']		 = 'Общая сумма заказа, для активации этого способа оплаты'; 

// Error 
$_['error_permission']   = 'Внимание: у вас нет прав на изменение платежа Pay Crypto!';
$_['error_bank']         = 'Требуется адрес криптокошелька!';