<?php
// Heading
$_['heading_title']		 = 'Pay Crypto (dev. by Shadowww)';

// Text
$_['text_extension']	 = 'Extensions';
$_['text_success']		 = 'Success: You have modified details of the Crypto Payment!';
$_['text_edit']          = 'Edit Blockchain Info';

// Entry
$_['entry_bank']		 = 'Crypto Wallet Address';
$_['entry_total']		 = 'Total';
$_['entry_order_status'] = 'Order Status';
$_['entry_geo_zone']	 = 'Geo Zone';
$_['entry_status']		 = 'Status';
$_['entry_sort_order']	 = 'Sort Order';
$_['entry_render_html']	 = 'Render address as HTML';

// Help
$_['help_total']		 = 'The checkout total the order must reach before this payment method becomes active.'; 

// Error 
$_['error_permission']   = 'Warning: You do not have permission to modify payment Pay Crypto!';
$_['error_bank']         = 'Crypto Wallet Address Required!';